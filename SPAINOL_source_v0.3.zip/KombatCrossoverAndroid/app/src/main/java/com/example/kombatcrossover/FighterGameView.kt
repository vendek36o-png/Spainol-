package com.example.kombatcrossover

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.media.AudioManager
import android.media.ToneGenerator
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * SPAINOL v0.3 - jeu de combat 2D 100% original (aucune ressource externe).
 * Modes : ARCADE (7 adversaires, meilleur des 3 rounds) et VERSUS 2 joueurs.
 * 8 combattants originaux, coups legers/lourds, blocage, coups speciaux, combos, COUP FINAL.
 */
class FighterGameView(context: Context) : View(context) {

    // ---------- Données ----------
    private class Spec(
        val name: String, val style: String, val special: String, val sType: Int, // 0 projectile, 1 charge, 2 séisme
        val main: Int, val dark: Int, val accent: Int,
        val power: Float, val speed: Float, val sDmg: Float, val ps: Float, val freeze: Boolean, val look: Int
    )

    private class Proj(
        var x: Float, val dir: Float, val owner: Int, val dmg: Float,
        val color: Int, val speed: Float, val stun: Float
    )

    private class Body(var idx: Int, val ai: Boolean) {
        var x = 0f
        var health = 100f
        var energy = 0f
        var jump = 0f
        var jv = 0f
        var atkTimer = 0f
        var atkType = 0 // 1 coup, 2 pied, 3 charge, 4 séisme, 5 projectile
        var atkDone = false
        var dashTimer = 0f
        var stun = 0f
        var flash = 0f
        var blocking = false
        var moving = false
        var walk = 0f
        var combo = 0
        var comboTimer = 0f
        var wins = 0
        // entrées
        var inL = false; var inR = false; var inJump = false; var inBlock = false
        var pPunch = false; var pKick = false; var pSpec = false
        // IA
        var aiClock = 0f
        var plan = 0

        fun resetRound(startX: Float) {
            x = startX; health = 100f; energy = 0f; jump = 0f; jv = 0f
            atkTimer = 0f; atkType = 0; atkDone = false; dashTimer = 0f
            stun = 0f; flash = 0f; blocking = false; combo = 0; comboTimer = 0f
            plan = 0; aiClock = .5f
        }
    }

    private val roster = listOf(
        Spec("VOLT", "ÉLECTRIQUE", "ÉCLAIR", 0, 0xFF22B8B0.toInt(), 0xFF105B68.toInt(), 0xFFFFD166.toInt(), 1.00f, 1.10f, 12f, 1.25f, false, 0),
        Spec("ONYX", "OMBRE", "LAME D'OMBRE", 1, 0xFF8B8FA8.toInt(), 0xFF303348.toInt(), 0xFFB5C7FF.toInt(), 1.00f, 1.15f, 14f, 0f, false, 1),
        Spec("BLAZE", "FEU", "BOULE DE FEU", 0, 0xFFE56B35.toInt(), 0xFF762D29.toInt(), 0xFFFFD166.toInt(), 1.05f, 1.00f, 14f, 1.00f, false, 2),
        Spec("FROST", "GLACE", "PIC DE GLACE", 0, 0xFF83C8E8.toInt(), 0xFF315B86.toInt(), 0xFFE4FAFF.toInt(), 0.95f, 1.00f, 10f, 1.00f, true, 3),
        Spec("RONIN", "COMBAT", "CHARGE DU SABRE", 1, 0xFFC9A66B.toInt(), 0xFF57412F.toInt(), 0xFFEAD9B5.toInt(), 1.10f, 1.10f, 16f, 0f, false, 4),
        Spec("VENOM", "TOXINE", "NUAGE TOXIQUE", 0, 0xFF8BC34A.toInt(), 0xFF36552C.toInt(), 0xFFD8FF83.toInt(), 1.00f, 1.00f, 11f, .55f, false, 5),
        Spec("NOVA", "ÉNERGIE", "ONDE NOVA", 0, 0xFFB18AE8.toInt(), 0xFF513B83.toInt(), 0xFFFFC7E8.toInt(), 0.90f, 1.05f, 18f, .90f, false, 6),
        Spec("TITAN", "FORCE", "SÉISME", 2, 0xFFB87878.toInt(), 0xFF59343D.toInt(), 0xFFFFD0A8.toInt(), 1.25f, .80f, 22f, 0f, false, 7)
    )

    private val pals = listOf(
        intArrayOf(0xFF090F20.toInt(), 0xFF172746.toInt(), 0xFF243653.toInt()),
        intArrayOf(0xFF1E0B14.toInt(), 0xFF3A1522.toInt(), 0xFF4D2030.toInt()),
        intArrayOf(0xFF0A1E14.toInt(), 0xFF153A26.toInt(), 0xFF20503A.toInt()),
        intArrayOf(0xFF1A1408.toInt(), 0xFF3B2E12.toInt(), 0xFF54421C.toInt())
    )

    // ---------- État ----------
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val buttons = mutableMapOf<Int, RectF>()
    private val labels = mutableMapOf<Int, String>()
    private val ui = mutableMapOf<String, RectF>()
    private val held = mutableSetOf<Int>()
    private val pressed = mutableSetOf<Int>()
    private val projs = mutableListOf<Proj>()
    private val prefs = context.getSharedPreferences("spainol", Context.MODE_PRIVATE)
    private val tone: ToneGenerator? = try { ToneGenerator(AudioManager.STREAM_MUSIC, 70) } catch (e: Exception) { null }

    private var state = 0 // 0 menu, 1 sélection, 2 combat, 3 résultat
    private var versus = false
    private var selPhase = 0
    private var pending = 0
    private var p1 = 0
    private var p2 = 2
    private var opps = listOf<Int>()
    private var stage = 0
    private var aiDiff = 0
    private var best = prefs.getInt("best", 0)
    private var palIdx = 0

    private var a = Body(0, false)
    private var b = Body(2, true)
    private var round = 1
    private var roundTime = 60f
    private var intro = 0f
    private var koTimer = 0f
    private var finalKo = false
    private var shake = 0f
    private var message = ""
    private var messageTimer = 0f
    private var resultTitle = ""
    private var resultSub = ""
    private var resultAction = 0 // 0 menu, 1 adversaire suivant, 2 réessayer, 3 re-sélection
    private var resultLock = 0f
    private var lastTime = System.nanoTime()

    // ---------- Son (bips générés, aucune ressource) ----------
    private fun sfx(kind: Int) {
        try {
            when (kind) {
                0 -> tone?.startTone(ToneGenerator.TONE_DTMF_6, 70)
                1 -> tone?.startTone(ToneGenerator.TONE_DTMF_9, 110)
                2 -> tone?.startTone(ToneGenerator.TONE_DTMF_3, 160)
                3 -> tone?.startTone(ToneGenerator.TONE_DTMF_1, 40)
                4 -> tone?.startTone(ToneGenerator.TONE_SUP_ERROR, 250)
                else -> tone?.startTone(ToneGenerator.TONE_PROP_ACK, 120)
            }
        } catch (e: Exception) {
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        try { tone?.release() } catch (e: Exception) { }
    }

    // ---------- Boucle ----------
    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val now = System.nanoTime()
        val dt = ((now - lastTime) / 1_000_000_000f).coerceIn(0f, .05f)
        lastTime = now
        val w = width.toFloat()
        val h = height.toFloat()
        ui.clear()
        if (state == 2) update(dt)
        messageTimer = max(0f, messageTimer - dt)
        shake = max(0f, shake - dt)
        resultLock = max(0f, resultLock - dt)

        c.save()
        if (state >= 2 && (shake > 0f || (finalKo && koTimer > 0f))) {
            c.translate((Random.nextFloat() - .5f) * h * .02f, (Random.nextFloat() - .5f) * h * .02f)
        }
        drawArena(c, w, h)
        when (state) {
            0 -> drawMenu(c, w, h)
            1 -> drawSelect(c, w, h)
            else -> {
                drawHud(c, w, h)
                drawProjs(c, w, h)
                drawFighter(c, w, h, a, b)
                drawFighter(c, w, h, b, a)
            }
        }
        c.restore()

        if (state == 2) {
            drawControls(c, w, h)
            if (koTimer > 0f) {
                if (finalKo) {
                    val alpha = (koTimer / 1.3f * 90f).toInt().coerceIn(0, 255)
                    p.color = (alpha shl 24) or 0x00FFFFFF
                    c.drawRect(0f, 0f, w, h, p)
                }
                p.textAlign = Paint.Align.CENTER
                p.typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
                p.color = if (finalKo) 0xFFFF4D4D.toInt() else 0xFFFFC15A.toInt()
                p.textSize = h * (if (finalKo) .13f else .17f)
                c.drawText(if (finalKo) "COUP FINAL !" else "K.O.", w / 2, h * .45f, p)
            } else if (messageTimer > 0f) {
                p.color = 0xFFFFFFFF.toInt(); p.textAlign = Paint.Align.CENTER; p.textSize = h * .07f
                p.typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
                c.drawText(message, w / 2, h * .30f, p)
            }
        }
        if (state == 3) drawOverlay(c, w, h)
        postInvalidateOnAnimation()
    }

    // ---------- Logique ----------
    private fun startMatch() {
        a = Body(p1, false)
        b = Body(p2, !versus)
        round = 1
        palIdx = if (versus) Random.nextInt(pals.size) else stage % pals.size
        beginRound()
        state = 2
        held.clear(); pressed.clear()
    }

    private fun beginRound() {
        a.resetRound(.25f); b.resetRound(.75f)
        projs.clear()
        roundTime = 60f
        intro = 1.8f
        koTimer = 0f
        finalKo = false
        message = "ROUND $round"; messageTimer = 1.6f
    }

    private fun update(dt: Float) {
        if (intro > 0f) {
            intro -= dt
            if (intro <= 0f) { message = "COMBAT !"; messageTimer = .7f }
            pressed.clear()
            return
        }
        val ko = koTimer > 0f
        val d = if (ko) dt * .35f else dt
        if (!ko) {
            roundTime -= dt
            if (roundTime <= 0f) {
                roundTime = 0f
                if (a.health >= b.health) b.health = 0f else a.health = 0f
            }
            readInput(a, 0); readInput(b, 1)
            if (a.ai) aiThink(a, b, dt)
            if (b.ai) aiThink(b, a, dt)
            if (Random.nextBoolean()) { act(a, b, d); act(b, a, d) } else { act(b, a, d); act(a, b, d) }
        }
        physics(a, d); physics(b, d)
        // séparation des combattants
        val gap = abs(a.x - b.x)
        if (gap < .06f && abs(a.jump - b.jump) < .3f) {
            val push = (.06f - gap) / 2f
            if (a.x <= b.x) { a.x -= push; b.x += push } else { a.x += push; b.x -= push }
        }
        a.x = a.x.coerceIn(.05f, .95f); b.x = b.x.coerceIn(.05f, .95f)
        updateProjs(d)
        if (!ko && (a.health <= 0f || b.health <= 0f)) startKo()
        if (ko) {
            koTimer -= dt
            if (koTimer <= 0f) endRound()
        }
        pressed.clear()
    }

    private fun startKo() {
        val winner = if (a.health > b.health) a else b
        finalKo = winner.wins + 1 >= 2
        koTimer = 1.3f
        shake = .4f
        sfx(4)
    }

    private fun endRound() {
        val winnerIsA = a.health > b.health
        val w = if (winnerIsA) a else b
        w.wins += 1
        if (w.wins >= 2) matchOver(winnerIsA) else { round += 1; beginRound() }
    }

    private fun matchOver(winnerIsA: Boolean) {
        state = 3
        resultLock = .8f
        if (versus) {
            resultTitle = "JOUEUR ${if (winnerIsA) 1 else 2} GAGNE !"
            resultSub = "TOUCHE L'ÉCRAN POUR REJOUER"
            resultAction = 3
        } else if (winnerIsA) {
            if (stage + 1 > best) { best = stage + 1; prefs.edit().putInt("best", best).apply() }
            if (stage >= opps.size - 1) {
                resultTitle = "CHAMPION !"
                resultSub = "TU AS BATTU LES ${opps.size} ADVERSAIRES"
                resultAction = 0
            } else {
                resultTitle = "VICTOIRE !"
                resultSub = "PROCHAIN ADVERSAIRE : ${roster[opps[stage + 1]].name}"
                resultAction = 1
            }
        } else {
            resultTitle = "DÉFAITE"
            resultSub = "TOUCHE L'ÉCRAN POUR RÉESSAYER"
            resultAction = 2
        }
        sfx(5)
    }

    private fun readInput(me: Body, pid: Int) {
        if (me.ai) return
        me.inL = held.contains(pid * 10); me.inR = held.contains(pid * 10 + 1)
        me.inJump = held.contains(pid * 10 + 2); me.inBlock = held.contains(pid * 10 + 3)
        me.pPunch = pressed.contains(pid * 10 + 4)
        me.pKick = pressed.contains(pid * 10 + 5)
        me.pSpec = pressed.contains(pid * 10 + 6)
    }

    private fun inRange(me: Body, o: Body, reach: Float): Boolean =
        abs(me.x - o.x) <= reach && abs(me.jump - o.jump) < .3f

    private fun act(me: Body, o: Body, dt: Float) {
        val f = roster[me.idx]
        me.stun = max(0f, me.stun - dt)
        me.atkTimer = max(0f, me.atkTimer - dt)
        if (me.atkTimer <= 0f) me.atkType = 0
        me.flash = max(0f, me.flash - dt)
        me.comboTimer -= dt
        if (me.comboTimer <= 0f) me.combo = 0
        me.energy = min(100f, me.energy + dt * 2.5f)
        me.moving = false
        val dir = if (o.x >= me.x) 1f else -1f
        if (me.stun > 0f) { me.blocking = false; return }
        if (me.dashTimer > 0f) {
            me.dashTimer -= dt
            me.x += dir * dt * 1.1f
            if (!me.atkDone && inRange(me, o, .09f)) {
                me.atkDone = true
                hit(me, o, f.sDmg, .4f, .05f)
            }
            return
        }
        me.blocking = me.inBlock && me.atkTimer <= 0f && me.jump == 0f
        if (me.blocking) return
        if (me.atkTimer > 0f) return
        val mv = (if (me.inR) 1f else 0f) - (if (me.inL) 1f else 0f)
        if (mv != 0f) { me.x += mv * .33f * f.speed * dt; me.walk += dt; me.moving = true }
        if (me.inJump && me.jump == 0f && me.jv == 0f) me.jv = 2.7f
        if (me.pPunch) {
            me.atkType = 1; me.atkTimer = .26f
            if (inRange(me, o, .14f)) hit(me, o, 6f * f.power, .22f, .012f)
        } else if (me.pKick) {
            me.atkType = 2; me.atkTimer = .38f
            if (inRange(me, o, .18f)) hit(me, o, 10f * f.power, .30f, .03f)
        } else if (me.pSpec && me.energy >= 50f) {
            me.energy -= 50f
            when (f.sType) {
                0 -> {
                    me.atkType = 5; me.atkTimer = .40f
                    projs.add(Proj(me.x + dir * .05f, dir, if (me === a) 0 else 1, f.sDmg, f.accent, f.ps, if (f.freeze) .9f else .35f))
                }
                1 -> { me.atkType = 3; me.atkTimer = .45f; me.dashTimer = .32f; me.atkDone = false }
                else -> {
                    me.atkType = 4; me.atkTimer = .60f; shake = .3f
                    if (inRange(me, o, .20f)) hit(me, o, f.sDmg, .6f, .08f)
                }
            }
            sfx(2)
            message = f.special; messageTimer = .7f
        }
    }

    private fun hit(att: Body, def: Body, dmgIn: Float, stunT: Float, kb: Float) {
        val away = if (def.x >= att.x) 1f else -1f
        var dmg = dmgIn
        if (att.ai) dmg *= (.65f + aiDiff * .06f)
        if (def.blocking) {
            def.x += away * .012f
            def.energy = min(100f, def.energy + 2f)
            att.combo = 0
            def.health = max(1f, def.health - dmg * .15f)
            sfx(3)
            return
        }
        att.combo += 1
        att.comboTimer = 1.2f
        dmg *= (1f - .1f * min(att.combo - 1, 5))
        def.health = max(0f, def.health - dmg)
        def.stun = stunT
        def.flash = .15f
        def.x += away * kb
        def.atkTimer = 0f; def.atkType = 0; def.dashTimer = 0f
        att.energy = min(100f, att.energy + 8f)
        def.energy = min(100f, def.energy + 4f)
        if (att.combo >= 2) { message = "COMBO x${att.combo}"; messageTimer = .6f }
        sfx(0)
    }

    private fun physics(me: Body, dt: Float) {
        if (me.jump > 0f || me.jv != 0f) {
            me.jump += me.jv * dt
            me.jv -= 7.5f * dt
            if (me.jump <= 0f) { me.jump = 0f; me.jv = 0f }
        }
    }

    private fun updateProjs(dt: Float) {
        val it = projs.iterator()
        while (it.hasNext()) {
            val pr = it.next()
            pr.x += pr.dir * pr.speed * dt
            val att = if (pr.owner == 0) a else b
            val def = if (pr.owner == 0) b else a
            if (abs(pr.x - def.x) < .04f && def.jump < .3f && def.health > 0f) {
                hit(att, def, pr.dmg, pr.stun, .03f)
                it.remove()
            } else if (pr.x < -.1f || pr.x > 1.1f) {
                it.remove()
            }
        }
    }

    private fun aiThink(me: Body, o: Body, dt: Float) {
        me.inL = false; me.inR = false; me.inJump = false; me.inBlock = false
        me.pPunch = false; me.pKick = false; me.pSpec = false
        val dist = abs(o.x - me.x)
        val toward = o.x >= me.x
        val f = roster[me.idx]
        me.aiClock -= dt
        if (me.aiClock <= 0f) {
            me.aiClock = max(.1f, .5f - aiDiff * .05f) + Random.nextFloat() * .2f
            val r = Random.nextFloat()
            me.plan = when {
                o.atkTimer > 0f && dist < .22f && r < .2f + aiDiff * .07f -> 4
                dist > .30f -> if (me.energy >= 50f && f.sType == 0 && r < .5f) 5 else if (r < .1f) 7 else 1
                dist > .18f -> if (r < .35f) 3 else if (r < .45f && me.energy >= 50f && f.sType == 1) 5 else 1
                else -> if (r < .35f) 2 else if (r < .6f) 3 else if (r < .7f && me.energy >= 50f) 5 else if (r < .85f) 6 else 4
            }
        }
        when (me.plan) {
            1 -> if (toward) me.inR = true else me.inL = true
            2 -> { me.pPunch = true; me.plan = 0; me.aiClock = max(.1f, .2f + Random.nextFloat() * .3f - aiDiff * .02f) }
            3 -> { me.pKick = true; me.plan = 0; me.aiClock = max(.1f, .2f + Random.nextFloat() * .3f - aiDiff * .02f) }
            4 -> me.inBlock = true
            5 -> { me.pSpec = true; me.plan = 0; me.aiClock = max(.1f, .2f + Random.nextFloat() * .3f - aiDiff * .02f) }
            6 -> if (toward) me.inL = true else me.inR = true
            7 -> me.inJump = true
        }
    }

    // ---------- Dessin ----------
    private fun box(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, r: Float) {
        c.drawRoundRect(min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2), r, r, p)
    }

    private fun tri(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float) {
        path.reset(); path.moveTo(x1, y1); path.lineTo(x2, y2); path.lineTo(x3, y3); path.close()
        c.drawPath(path, p)
    }

    private fun drawArena(c: Canvas, w: Float, h: Float) {
        val pal = pals[palIdx]
        c.drawColor(pal[0])
        p.color = pal[1]; c.drawCircle(w * .18f, h * .34f, h * .42f, p); c.drawCircle(w * .83f, h * .30f, h * .38f, p)
        p.color = pal[2]
        path.reset()
        path.moveTo(0f, h * .69f); path.lineTo(w * .16f, h * .47f); path.lineTo(w * .32f, h * .68f)
        path.lineTo(w * .53f, h * .43f); path.lineTo(w * .76f, h * .68f); path.lineTo(w * .91f, h * .49f)
        path.lineTo(w, h * .65f); path.lineTo(w, h * .74f); path.lineTo(0f, h * .74f); path.close()
        c.drawPath(path, p)
        p.color = 0xFF30394C.toInt(); c.drawRect(0f, h * .70f, w, h, p)
        p.color = 0xFF171F31.toInt(); c.drawRect(0f, h * .78f, w, h, p)
        p.color = 0xFFFFB45C.toInt(); c.drawRect(0f, h * .697f, w, h * .712f, p)
        p.color = 0x3349C6E5
        for (i in 0..12) c.drawRect(i * w / 13, h * .72f, (i * w / 13) + 2, h, p)
    }

    private fun button(c: Canvas, key: String, r: RectF, label: String) {
        ui[key] = r
        p.color = 0xFFFFB45C.toInt(); c.drawRoundRect(r, 16f, 16f, p)
        p.color = 0xFF18243A.toInt(); p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.DEFAULT_BOLD
        p.textSize = r.height() * .42f
        c.drawText(label, r.centerX(), r.centerY() + p.textSize * .34f, p)
    }

    private fun drawMenu(c: Canvas, w: Float, h: Float) {
        p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        p.color = 0xFFFFC15A.toInt(); p.textSize = h * .17f; c.drawText("SPAINOL", w / 2, h * .30f, p)
        p.color = 0xFFFFFFFF.toInt(); p.textSize = h * .045f; c.drawText("COMBAT • ARCADE • VERSUS", w / 2, h * .39f, p)
        button(c, "arcade", RectF(w * .30f, h * .46f, w * .70f, h * .60f), "ARCADE")
        button(c, "versus", RectF(w * .30f, h * .65f, w * .70f, h * .79f), "VERSUS 2 JOUEURS")
        p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.DEFAULT_BOLD
        p.textSize = h * .03f; p.color = 0xFFB9C8E8.toInt()
        c.drawText("MEILLEUR SCORE ARCADE : $best / 7  •  v0.3", w / 2, h * .90f, p)
    }

    private fun cell(i: Int, w: Float, h: Float): RectF {
        val cw = w * .205f; val ch = h * .27f; val gap = w * .025f
        val col = i % 4; val row = i / 4
        val x = w * .075f + col * (cw + gap); val y = h * .30f + row * (ch + h * .05f)
        return RectF(x, y, x + cw, y + ch)
    }

    private fun drawSelect(c: Canvas, w: Float, h: Float) {
        p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.DEFAULT_BOLD; p.color = 0xFFFFFFFF.toInt(); p.textSize = h * .065f
        val title = if (versus) "JOUEUR ${selPhase + 1} : CHOISIS TON COMBATTANT" else "CHOISIS TON COMBATTANT"
        c.drawText(title, w / 2, h * .13f, p)
        val sp = roster[pending]
        p.textSize = h * .03f; p.color = 0xFFD5E0F5.toInt()
        c.drawText("${sp.name} • ${sp.style} • SPÉCIAL : ${sp.special}", w / 2, h * .21f, p)
        for (i in roster.indices) {
            val r = cell(i, w, h)
            ui["pick$i"] = r
            p.color = if (i == pending) 0xFFFFB45C.toInt() else 0xAA25334E.toInt()
            c.drawRoundRect(r, 14f, 14f, p)
            drawMini(c, r.centerX(), r.top + r.height() * .48f, roster[i])
            p.color = 0xFFFFFFFF.toInt(); p.textAlign = Paint.Align.CENTER; p.textSize = h * .035f
            c.drawText(roster[i].name, r.centerX(), r.bottom - h * .03f, p)
        }
        button(c, "ok", RectF(w * .39f, h * .86f, w * .61f, h * .97f), "VALIDER")
        ui["back"] = RectF(w * .02f, h * .02f, w * .14f, h * .10f)
        p.color = 0x99FFFFFF.toInt(); c.drawRoundRect(ui["back"]!!, 12f, 12f, p)
        p.color = 0xFF18243A.toInt(); p.textSize = h * .035f; p.textAlign = Paint.Align.CENTER
        c.drawText("MENU", w * .08f, h * .072f, p)
    }

    private fun drawMini(c: Canvas, x: Float, y: Float, f: Spec) {
        p.color = f.dark; c.drawRoundRect(x - 19, y - 4, x + 19, y + 54, 9f, 9f, p)
        p.color = f.main; c.drawRoundRect(x - 14, y, x + 14, y + 40, 7f, 7f, p)
        p.color = f.accent; c.drawRect(x - 27, y + 5, x - 17, y + 19, p); c.drawRect(x + 17, y + 5, x + 27, y + 19, p)
        drawHead(c, x, y - 20, 18f, f, 1f, f.main, f.dark)
    }

    private fun drawHead(c: Canvas, cx: Float, cy: Float, r: Float, f: Spec, dir: Float, main: Int, dark: Int) {
        if (f.look == 1) { p.color = dark; c.drawCircle(cx, cy, r * 1.18f, p) }
        if (f.look == 7) {
            p.color = f.accent
            tri(c, cx - r * .8f, cy - r * .5f, cx - r * 1.4f, cy - r * 1.5f, cx - r * .2f, cy - r * .9f)
            tri(c, cx + r * .8f, cy - r * .5f, cx + r * 1.4f, cy - r * 1.5f, cx + r * .2f, cy - r * .9f)
        }
        p.color = f.accent; c.drawCircle(cx, cy, r, p)
        when (f.look) {
            0, 2 -> {
                p.color = main
                tri(c, cx - r * .9f, cy - r * .4f, cx - r * .5f, cy - r * 1.7f, cx - r * .1f, cy - r * .9f)
                tri(c, cx - r * .3f, cy - r * .9f, cx + r * .1f, cy - r * 1.9f, cx + r * .5f, cy - r * .9f)
                tri(c, cx + r * .2f, cy - r * .9f, cx + r * .6f, cy - r * 1.6f, cx + r * .95f, cy - r * .3f)
            }
            3 -> {
                p.color = 0xFFE4FAFF.toInt()
                tri(c, cx - r * .6f, cy - r * .8f, cx - r * .3f, cy - r * 1.8f, cx, cy - r * .9f)
                tri(c, cx, cy - r * .9f, cx + r * .3f, cy - r * 1.6f, cx + r * .6f, cy - r * .8f)
            }
            4 -> {
                p.color = main
                c.drawRect(cx - r, cy - r * .5f, cx + r, cy - r * .15f, p)
                tri(c, cx - dir * r, cy - r * .5f, cx - dir * r * 1.9f, cy - r * .1f, cx - dir * r, cy - r * .15f)
            }
            5 -> { p.color = dark; c.drawRect(cx - r * .85f, cy + r * .05f, cx + r * .85f, cy + r * .7f, p) }
            6 -> {
                p.color = f.main; p.style = Paint.Style.STROKE; p.strokeWidth = r * .18f
                c.drawCircle(cx, cy - r * 1.6f, r * .6f, p)
                p.style = Paint.Style.FILL
            }
        }
        p.color = 0xFF172033.toInt()
        c.drawOval(cx + dir * r * .25f - r * .55f, cy - r * .25f, cx + dir * r * .25f + r * .55f, cy + r * .2f, p)
    }

    private fun drawHud(c: Canvas, w: Float, h: Float) {
        p.typeface = Typeface.create("sans-serif-black", Typeface.BOLD); p.textSize = h * .043f; p.color = 0xFFFFFFFF.toInt()
        p.textAlign = Paint.Align.LEFT; c.drawText(roster[a.idx].name, w * .05f, h * .07f, p)
        p.textAlign = Paint.Align.RIGHT; c.drawText(roster[b.idx].name, w * .95f, h * .07f, p)
        p.color = 0xFF101522.toInt()
        c.drawRoundRect(w * .05f, h * .095f, w * .45f, h * .145f, 9f, 9f, p)
        c.drawRoundRect(w * .55f, h * .095f, w * .95f, h * .145f, 9f, 9f, p)
        p.color = 0xFF50D890.toInt()
        c.drawRoundRect(w * .05f, h * .095f, w * (.05f + .4f * a.health / 100f), h * .145f, 9f, 9f, p)
        p.color = 0xFFE75D65.toInt()
        c.drawRoundRect(w * (.95f - .4f * b.health / 100f), h * .095f, w * .95f, h * .145f, 9f, 9f, p)
        // énergie
        p.color = 0xFF101522.toInt()
        c.drawRect(w * .05f, h * .152f, w * .45f, h * .172f, p); c.drawRect(w * .55f, h * .152f, w * .95f, h * .172f, p)
        p.color = if (a.energy >= 50f) 0xFFFFD166.toInt() else 0xFF4FA3E0.toInt()
        c.drawRect(w * .05f, h * .152f, w * (.05f + .4f * a.energy / 100f), h * .172f, p)
        p.color = if (b.energy >= 50f) 0xFFFFD166.toInt() else 0xFF4FA3E0.toInt()
        c.drawRect(w * (.95f - .4f * b.energy / 100f), h * .152f, w * .95f, h * .172f, p)
        // manches gagnées
        for (i in 0..1) {
            p.color = if (a.wins > i) 0xFFFFC15A.toInt() else 0x55FFFFFF
            c.drawCircle(w * .06f + i * w * .03f, h * .215f, h * .012f, p)
            p.color = if (b.wins > i) 0xFFFFC15A.toInt() else 0x55FFFFFF
            c.drawCircle(w * .94f - i * w * .03f, h * .215f, h * .012f, p)
        }
        // chrono
        p.textAlign = Paint.Align.CENTER; p.color = 0xFFFFD18A.toInt(); p.textSize = h * .07f
        c.drawText(ceil(roundTime.toDouble()).toInt().toString(), w / 2, h * .12f, p)
        p.textSize = h * .03f; c.drawText("ROUND $round", w / 2, h * .052f, p)
        // combos
        p.textSize = h * .04f; p.color = 0xFFFFFFFF.toInt()
        if (a.combo >= 2 && a.comboTimer > 0f) { p.textAlign = Paint.Align.LEFT; c.drawText("COMBO x${a.combo}", w * .05f, h * .29f, p) }
        if (b.combo >= 2 && b.comboTimer > 0f) { p.textAlign = Paint.Align.RIGHT; c.drawText("COMBO x${b.combo}", w * .95f, h * .29f, p) }
        // bouton menu
        val q = RectF(w * .46f, h * .16f, w * .54f, h * .215f)
        ui["quit"] = q
        p.color = 0x66FFFFFF; c.drawRoundRect(q, 10f, 10f, p)
        p.color = 0xFFFFFFFF.toInt(); p.textSize = h * .026f; p.textAlign = Paint.Align.CENTER
        c.drawText("MENU", q.centerX(), q.centerY() + h * .009f, p)
    }

    private fun drawProjs(c: Canvas, w: Float, h: Float) {
        val s = h * .0011f
        for (pr in projs) {
            val x = pr.x * w; val y = h * .70f - 85 * s
            p.color = (pr.color and 0x00FFFFFF) or 0x55000000
            c.drawCircle(x - pr.dir * 22 * s, y, 11 * s, p); c.drawCircle(x - pr.dir * 40 * s, y, 7 * s, p)
            p.color = pr.color; c.drawCircle(x, y, 17 * s, p)
            p.color = 0xFFFFFFFF.toInt(); c.drawCircle(x, y, 8 * s, p)
        }
    }

    private fun drawFighter(c: Canvas, w: Float, h: Float, me: Body, o: Body) {
        val f = roster[me.idx]
        val s = h * .0011f
        val dir = if (o.x >= me.x) 1f else -1f
        val gy = h * .70f
        val floor = gy - me.jump * h * .30f
        val hitFlash = me.flash > 0f
        val main = if (hitFlash) 0xFFFFFFFF.toInt() else f.main
        val dark = if (hitFlash) 0xFFDDDDDD.toInt() else f.dark
        val lean = (if (me.stun > 0f) -7f else if (me.atkType == 3 && me.atkTimer > 0f) 9f else 0f) * s * dir
        val x = me.x * w + lean
        val swing = if (me.moving) sin(me.walk * 14f) * 9f * s else 0f
        val kicking = me.atkType == 2 && me.atkTimer > 0f

        p.color = 0x66000000; c.drawOval(me.x * w - 39 * s, gy - 4 * s, me.x * w + 39 * s, gy + 8 * s, p)
        // jambes
        p.color = dark
        box(c, x - 22 * s + swing, floor - 45 * s, x - 7 * s + swing, floor - 7 * s, 4 * s)
        if (kicking) {
            box(c, x + dir * 7 * s, floor - 62 * s, x + dir * 58 * s, floor - 46 * s, 6 * s)
            p.color = f.accent; c.drawCircle(x + dir * 58 * s, floor - 54 * s, 9 * s, p)
        } else {
            box(c, x + 7 * s - swing, floor - 45 * s, x + 22 * s - swing, floor - 7 * s, 4 * s)
        }
        // torse
        p.color = dark; box(c, x - 24 * s, floor - 104 * s, x + 24 * s, floor - 38 * s, 12 * s)
        p.color = main; box(c, x - 19 * s, floor - 100 * s, x + 19 * s, floor - 42 * s, 9 * s)
        // tête
        drawHead(c, x - dir * (if (me.stun > 0f) 5f * s else 0f), floor - 125 * s, 20 * s, f, dir, main, dark)
        // bras
        val active = me.atkTimer > 0f
        if (me.blocking) {
            p.color = f.accent; box(c, x + dir * 12 * s, floor - 116 * s, x + dir * 30 * s, floor - 58 * s, 7 * s)
            p.color = 0x4DFFFFFF; c.drawCircle(x + dir * 28 * s, floor - 85 * s, 44 * s, p)
        } else {
            val reach = if (active && (me.atkType == 1 || me.atkType >= 3)) (if (me.atkType == 1) 52f else 64f) * s else 0f
            p.color = main; box(c, x + dir * 17 * s, floor - 91 * s, x + dir * (38 * s + reach), floor - 76 * s, 7 * s)
            p.color = f.accent; c.drawCircle(x + dir * (38 * s + reach), floor - 84 * s, 8 * s, p)
        }
        // effets
        if (active && me.atkType >= 3) {
            p.color = (f.accent and 0x00FFFFFF) or 0x44000000
            c.drawCircle(x, floor - 80 * s, 62 * s, p)
        }
        if (active && me.atkType == 4) {
            val rad = (1f - me.atkTimer / .6f) * h * .25f
            p.style = Paint.Style.STROKE; p.strokeWidth = 8 * s
            p.color = (f.accent and 0x00FFFFFF) or 0xAA000000.toInt()
            c.drawOval(me.x * w - rad, gy - rad * .25f, me.x * w + rad, gy + rad * .25f, p)
            p.style = Paint.Style.FILL
        }
        if (me.stun > 0.05f && me.flash > 0f) {
            p.color = 0x88FFFFFF.toInt(); c.drawCircle(x, floor - 80 * s, 48 * s, p)
        }
    }

    private fun drawControls(c: Canvas, w: Float, h: Float) {
        buttons.clear(); labels.clear()
        val s = h * .11f
        val g = h * .012f
        val y1 = h * .765f
        val y2 = y1 + s + g
        fun add(id: Int, label: String, x: Float, y: Float) { buttons[id] = RectF(x, y, x + s, y + s); labels[id] = label }
        if (!versus) {
            val x0 = w * .03f
            add(2, "SAUT", x0, y1); add(3, "BLOC", x0 + s + g, y1)
            add(0, "◀", x0, y2); add(1, "▶", x0 + s + g, y2)
            val xr = w * .97f - 2 * s - g
            add(4, "COUP", xr, y1); add(5, "PIED", xr + s + g, y1)
            add(6, "SPÉ", xr + (s + g) / 2f, y2)
        } else {
            val ks = listOf("◀", "▶", "SAUT", "BLOC", "COUP", "PIED", "SPÉ")
            for (pid in 0..1) {
                val x0 = if (pid == 0) w * .02f else w * .98f - 4 * s - 3 * g
                for (k in 0..6) {
                    val col = if (k < 4) k else k - 4
                    val row = if (k < 4) 0 else 1
                    add(pid * 10 + k, ks[k], x0 + col * (s + g), if (row == 0) y1 else y2)
                }
            }
        }
        p.typeface = Typeface.DEFAULT_BOLD
        for ((id, r) in buttons) {
            val lab = labels[id] ?: ""
            p.color = if (held.contains(id)) 0xFFFFB45C.toInt() else 0xCCFFFFFF.toInt()
            c.drawRoundRect(r, 16f, 16f, p)
            p.color = 0xFF17243A.toInt(); p.textAlign = Paint.Align.CENTER
            p.textSize = if (lab.length > 2) h * .026f else h * .06f
            c.drawText(lab, r.centerX(), r.centerY() + p.textSize * .34f, p)
        }
    }

    private fun drawOverlay(c: Canvas, w: Float, h: Float) {
        p.color = 0xCC080D19.toInt(); c.drawRect(0f, 0f, w, h, p)
        p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.DEFAULT_BOLD
        p.color = 0xFFFFC15A.toInt(); p.textSize = h * .12f; c.drawText(resultTitle, w / 2, h * .45f, p)
        p.color = 0xFFFFFFFF.toInt(); p.textSize = h * .04f; c.drawText(resultSub, w / 2, h * .55f, p)
    }

    // ---------- Tactile ----------
    private fun tapUi(x: Float, y: Float): String? {
        for ((k, r) in ui) if (r.contains(x, y)) return k
        return null
    }

    private fun confirmSelect() {
        if (selPhase == 0) {
            p1 = pending
            if (versus) {
                selPhase = 1; pending = (p1 + 1) % roster.size
            } else {
                opps = (0 until roster.size).filter { it != p1 }.shuffled()
                stage = 0; p2 = opps[0]; aiDiff = 0
                startMatch()
            }
        } else {
            p2 = pending
            startMatch()
        }
    }

    private fun handleTap(x: Float, y: Float) {
        when (state) {
            0 -> when (tapUi(x, y)) {
                "arcade" -> { versus = false; selPhase = 0; pending = p1; state = 1 }
                "versus" -> { versus = true; selPhase = 0; pending = p1; state = 1 }
            }
            1 -> {
                val k = tapUi(x, y) ?: return
                if (k.startsWith("pick")) pending = k.substring(4).toInt()
                else if (k == "back") state = 0
                else if (k == "ok") confirmSelect()
            }
            3 -> {
                if (resultLock > 0f) return
                when (resultAction) {
                    0 -> state = 0
                    1 -> { stage += 1; p2 = opps[stage]; aiDiff = stage; startMatch() }
                    2 -> startMatch()
                    else -> { state = 1; selPhase = 0; pending = p1 }
                }
            }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val action = e.actionMasked
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
            val x = e.getX(e.actionIndex); val y = e.getY(e.actionIndex)
            if (state != 2) { handleTap(x, y); return true }
            val q = ui["quit"]
            if (q != null && q.contains(x, y)) { state = 0; held.clear(); pressed.clear(); return true }
        }
        if (state == 2) {
            val now = mutableSetOf<Int>()
            for (i in 0 until e.pointerCount) {
                if ((action == MotionEvent.ACTION_POINTER_UP && i == e.actionIndex) ||
                    action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) continue
                val x = e.getX(i); val y = e.getY(i)
                for ((k, r) in buttons) if (r.contains(x, y)) now.add(k)
            }
            for (k in now) if (!held.contains(k)) pressed.add(k)
            held.clear(); held.addAll(now)
        }
        return true
    }
}
