SPAINOL v0.3 — jeu de combat Android 100 % original

CONTENU
- Modes : ARCADE (7 adversaires, meilleur des 3 rounds) et VERSUS 2 joueurs sur le même écran.
- 8 combattants originaux avec un coup spécial chacun :
  VOLT (éclair), ONYX (lame d'ombre), BLAZE (boule de feu), FROST (pic de glace, gèle),
  RONIN (charge du sabre), VENOM (nuage toxique), NOVA (onde), TITAN (séisme).
- Commandes : ◀ ▶ SAUT BLOC COUP PIED SPÉ.
- Jauge d'énergie : elle monte avec le temps et en frappant ; le SPÉCIAL coûte 50.
- Combos (compteur visible), blocage, chrono de 60 s, K.O. au ralenti et « COUP FINAL ! » sur le dernier round.
- Sons générés par le téléphone (bips), aucune ressource externe.
- Meilleur score arcade sauvegardé.

AUCUNE ressource de Mortal Kombat, Killer Instinct ou d'une ROM n'est utilisée.

COMPILATION : voir DEMARRER_SUR_ANDROID.txt (GitHub Actions, sans Android Studio).
