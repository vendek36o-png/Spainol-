PROJET : SPAINOL — prototype Android 0.1

Ce dossier contient le CODE SOURCE d'un premier prototype Android en paysage,
plein écran immersif, avec commandes tactiles, une arène provisoire et deux
combattants génériques originaux.

IMPORTANT
- Ce n'est PAS encore l'APK installable.
- Il faut ouvrir ce dossier dans Android Studio puis compiler l'application.
- Le prototype ne contient pas encore les personnages, sprites, sons ou décors
  des deux jeux commerciaux.
- Les ROM fournies servent de référence technique uniquement. N'intégrez pas
  leurs graphismes, sons ou autres ressources dans une APK distribuée sans
  autorisation des ayants droit.
- Les combattants dessinés ici sont des silhouettes provisoires originales.

COMPILATION
1. Installer Android Studio et le SDK Android 35.
2. Ouvrir le dossier Spainol dans Android Studio.
3. Laisser Gradle synchroniser le projet.
4. Choisir Build > Build Bundle(s) / APK(s) > Build APK(s).
5. L'APK de débogage sera généralement dans app/build/outputs/apk/debug/.

CIBLE
- Android minimum : 6.0 (API 23)
- Orientation : paysage
- Affichage : plein écran immersif
- Version : 0.1-prototype

PROCHAINES ÉTAPES
- Créer le roster complet avec des personnages originaux ou des ressources
  dont les droits d'utilisation sont obtenus.
- Concevoir des sprites et animations haute qualité.
- Ajouter sélection des combattants, modes arcade et versus, combos,
  coups spéciaux, sons, menus, sauvegarde et équilibrage.
- Optimiser le rendu pour différents formats d'écran Android.
