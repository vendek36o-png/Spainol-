package com.example.kombatcrossover

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min

class FighterGameView(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var playerX = 0.22f
    private var enemyX = 0.78f
    private var playerHealth = 100f
    private var enemyHealth = 100f
    private var playerJump = 0f
    private var enemyFlash = 0f
    private var message = "ROUND 1  •  FIGHT!"
    private var messageTimer = 2.0f
    private var lastTime = System.nanoTime()
    private val held = mutableSetOf<Int>()
    private val buttons = mutableMapOf<Int, RectF>()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val dt = ((System.nanoTime() - lastTime) / 1_000_000_000f).coerceIn(0f, 0.05f)
        lastTime = System.nanoTime()
        update(dt)
        val w = width.toFloat()
        val h = height.toFloat()

        // Original placeholder arena: dusk sky, distant mountains and fighting platform.
        canvas.drawColor(0xFF10172B.toInt())
        p.color = 0xFF26375B.toInt()
        canvas.drawOval(-w * .2f, h * .25f, w * .45f, h * .85f, p)
        canvas.drawOval(w * .48f, h * .18f, w * 1.2f, h * .85f, p)
        p.color = 0xFF53617A.toInt()
        canvas.drawRect(0f, h * .72f, w, h, p)
        p.color = 0xFF202B3D.toInt()
        canvas.drawRect(0f, h * .78f, w, h, p)
        p.color = 0xFFDF9B55.toInt()
        canvas.drawRect(0f, h * .70f, w, h * .715f, p)

        drawHud(canvas, w, h)
        drawFighter(canvas, playerX * w, h * .70f - playerJump, true)
        drawFighter(canvas, enemyX * w, h * .70f - if (enemyFlash > 0f) 8f else 0f, false)
        drawControls(canvas, w, h)

        if (messageTimer > 0f) {
            p.color = 0xFFFFFFFF.toInt()
            p.textAlign = Paint.Align.CENTER
            p.textSize = h * .065f
            p.setShadowLayer(5f, 2f, 2f, 0xFF000000.toInt())
            canvas.drawText(message, w / 2f, h * .22f, p)
            p.clearShadowLayer()
        }
        postInvalidateOnAnimation()
    }

    private fun update(dt: Float) {
        val speed = dt * 0.55f
        if (held.contains(0)) playerX = max(.06f, playerX - speed)
        if (held.contains(1)) playerX = min(.48f, playerX + speed)
        if (held.contains(2) && playerJump == 0f) playerJump = 1f
        if (playerJump > 0f) {
            playerJump = max(0f, playerJump - dt * 2.1f)
        }
        if (held.contains(3)) {
            if (kotlin.math.abs(playerX - enemyX) < .24f && enemyFlash <= 0f) {
                enemyHealth = max(0f, enemyHealth - 22f)
                enemyFlash = .25f
                message = "HIT!"
                messageTimer = .45f
            }
        }
        enemyFlash = max(0f, enemyFlash - dt)
        if (messageTimer > 0f) messageTimer -= dt
        if (enemyHealth <= 0f) {
            message = "YOU WIN!  TAP ATTACK TO RESTART"
            messageTimer = 0.1f
            if (held.contains(3)) {
                enemyHealth = 100f
                playerHealth = 100f
                playerX = .22f
                enemyX = .78f
            }
        }
        // Simple training dummy AI: slowly approaches the player.
        if (enemyX - playerX > .29f) enemyX = max(.55f, enemyX - dt * .07f)
    }

    private fun drawHud(c: Canvas, w: Float, h: Float) {
        p.color = 0xFFFFFFFF.toInt()
        p.textSize = h * .045f
        p.textAlign = Paint.Align.LEFT
        c.drawText("FIGHTER 01", w * .05f, h * .075f, p)
        p.textAlign = Paint.Align.RIGHT
        c.drawText("RIVAL", w * .95f, h * .075f, p)
        p.color = 0xFF202020.toInt()
        c.drawRoundRect(w*.05f, h*.10f, w*.45f, h*.145f, 8f, 8f, p)
        c.drawRoundRect(w*.55f, h*.10f, w*.95f, h*.145f, 8f, 8f, p)
        p.color = 0xFF52D273.toInt()
        c.drawRoundRect(w*.05f, h*.10f, w*(.05f + .40f*playerHealth/100f), h*.145f, 8f, 8f, p)
        p.color = 0xFFE45B58.toInt()
        c.drawRoundRect(w*(.95f - .40f*enemyHealth/100f), h*.10f, w*.95f, h*.145f, 8f, 8f, p)
    }

    private fun drawFighter(c: Canvas, x: Float, floor: Float, hero: Boolean) {
        val scale = height * .001f
        val body = if (hero) 0xFF25A8A0.toInt() else 0xFFB94B54.toInt()
        val dark = if (hero) 0xFF135A65.toInt() else 0xFF63283B.toInt()
        p.color = 0x66000000
        c.drawOval(x-36*scale, floor-5*scale, x+36*scale, floor+8*scale, p)
        // Original, deliberately generic prototype fighter silhouette.
        p.color = dark
        c.drawRoundRect(x-25*scale, floor-104*scale, x+25*scale, floor-38*scale, 13*scale, 13*scale, p)
        p.color = body
        c.drawRoundRect(x-20*scale, floor-100*scale, x+20*scale, floor-42*scale, 10*scale, 10*scale, p)
        c.drawCircle(x, floor-123*scale, 19*scale, p)
        p.color = 0xFFE7C4A1.toInt()
        c.drawCircle(x, floor-124*scale, 14*scale, p)
        p.color = dark
        c.drawRect(x-23*scale, floor-45*scale, x-7*scale, floor-7*scale, p)
        c.drawRect(x+7*scale, floor-45*scale, x+23*scale, floor-7*scale, p)
        p.color = body
        c.drawRoundRect(x-38*scale, floor-91*scale, x-17*scale, floor-77*scale, 7*scale, 7*scale, p)
        c.drawRoundRect(x+17*scale, floor-91*scale, x+38*scale, floor-77*scale, 7*scale, 7*scale, p)
        if (enemyFlash > 0f && !hero) {
            p.color = 0x88FFFFFF.toInt()
            c.drawCircle(x, floor-80*scale, 49*scale, p)
        }
    }

    private fun drawControls(c: Canvas, w: Float, h: Float) {
        buttons.clear()
        val size = h * .17f
        val y = h * .78f
        val specs = listOf(
            Triple(0, "◀", w*.06f), Triple(1, "▶", w*.06f + size*1.15f),
            Triple(2, "JUMP", w*.69f), Triple(3, "HIT", w*.82f)
        )
        for ((id, label, x) in specs) {
            val r = RectF(x, y, x+size, y+size)
            buttons[id] = r
            p.color = if (held.contains(id)) 0xFFDAA34D.toInt() else 0xAAFFFFFF.toInt()
            c.drawRoundRect(r, 18f, 18f, p)
            p.color = 0xFF152033.toInt()
            p.textAlign = Paint.Align.CENTER
            p.textSize = if (label.length > 2) h*.035f else h*.075f
            c.drawText(label, r.centerX(), r.centerY()+p.textSize*.34f, p)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val id = event.getPointerId(event.actionIndex)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val x = event.getX(event.actionIndex)
                val y = event.getY(event.actionIndex)
                buttons.forEach { (key, rect) -> if (rect.contains(x, y)) held.add(key) }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                held.clear()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                held.clear()
                for (i in 0 until event.pointerCount) {
                    val x = event.getX(i); val y = event.getY(i)
                    buttons.forEach { (key, rect) -> if (rect.contains(x, y)) held.add(key) }
                }
                return true
            }
        }
        return true
    }
}
